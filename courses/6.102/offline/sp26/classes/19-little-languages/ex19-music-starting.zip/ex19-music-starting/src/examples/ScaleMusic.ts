import { Music } from '../Music.ts';
import { notes } from '../MusicLanguage.ts';
import { Instrument } from '../Instrument.ts';
import { playOnMidiPlayer } from '../MusicPlayer.ts';

/*
 * Play an octave up and back down starting from middle C.
 */

// parse simplified abc into a Music
const scale: Music = notes("C D E F G A B C' B A G F E D C", Instrument.PIANO);

console.log(scale.toString());

// play!
console.log('playing now...');
await playOnMidiPlayer(scale);
console.log('playing done');
