import { main } from './parser.ts';

main();
